import meggy.Meggy;

class PA5Test4 {

    public static void main(String[] whatever){

			new Class_1().rain((byte)3,(byte)7);

    }
    

}

class Class_1{
	public void rain( byte a, byte b){
		byte i;
		byte j;
		int k;
		i = (byte)3;
		j = (byte)4;
    	Meggy.setPixel(i, j, Meggy.Color.BLUE);
  	}
  
}
