
import meggy.Meggy;

class PATest {

    public static void main(String[] whatever){

			new Class_1().rain((byte)3,(byte)7);

    }
    

}

class Class_1{
	byte i;
	public void rain( byte a, byte b){
		
		i = (byte)3;
    	Meggy.setPixel(i, b, Meggy.Color.BLUE);
  	}
  
}
