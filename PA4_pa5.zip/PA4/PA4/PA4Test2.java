/**
 * PA4Test2.java
 * Testing function calls copy color to another pixel.
 */

import meggy.Meggy;

class PA4Test2 {

    public static void main(String[] args){
        {   
        	
			Meggy.setPixel((byte)1, (byte)2, Meggy.Color.YELLOW);

			new Utility().setColor((byte)2, (byte)3, new Utility().checkColor((byte)1, (byte)2));
//new Utility().setColor((byte)2, (byte)3, Meggy.Color.YELLOW);
        }
    }
}

class Utility {

    public Meggy.Color checkColor(byte x, byte y){
    	return Meggy.getPixel(x, y);
    }
    public boolean setColor(byte x, byte y, Meggy.Color color){
    	
    	if(Meggy.getPixel(x, y) == Meggy.Color.YELLOW){
    		Meggy.setPixel(x, y, color);
    		
    	} else {
    		Meggy.setPixel(x, y, color);
    		
    	}
    	
    	return true;
    	
    }
}

