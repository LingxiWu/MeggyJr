Name: Lingxi Wu
Computing ID: lw2ef

To make PA4 compiler, in PA4/PA4 type in "make clean;make"
To test any cases, type "java -jar MJ.jar PATest.java"

To test batch files, in /Test, type in ./regress.sh

in PA4/PA4 there are PA4Test1.java, PA4Test2.java, PA4Test3.java and PA4raindrop.java, PA4Mazesolver.java, PA4bluedot.java. 

PA4Example1 - PA4Example3, PA4Example6 test cases are for small set of features
PA4Example4, PA4Example5, PA4Example7, PA4Example8 are meant to fail due to imcompatible types, double method def, no method def, and etc.

I developed a series of test cases for PA5, some of them contain incorrect grammars:
	
PA5Test1 - 

Test cases designed to fail:
PA5Test5, PA5Test6




