import meggy.Meggy;

class PA5Test5 {

    public static void main(String[] whatever){

			new Class_1().rain((byte)3,(byte)7);

    }
    

}

class Class_1{

	int int1;
	
	public void rain( byte a, byte b){
		byte i;
		byte j;
		j = 3;
		int1 = 5;
		//i = (byte)3;
		//j = (byte)4;
    	Meggy.setPixel(i, 5, Meggy.Color.BLUE);
  	}
  
}
