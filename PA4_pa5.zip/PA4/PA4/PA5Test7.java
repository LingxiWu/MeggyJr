import meggy.Meggy;

class PA5Test7 {

    public static void main(String[] whatever){
    	new Class_1().rain((byte)3,(byte)7);
		new Class_2().rain((byte)3,(byte)7);
    }
    

}

class Class_1{
	int j;
	public void rain( byte a, byte b){
		j = 10;
  	}
  
}

class Class_2{
	int k;
	byte u;
	public void rain( byte a, byte b){
		k = 8;
		u = (byte)8;
  	}
  
}
