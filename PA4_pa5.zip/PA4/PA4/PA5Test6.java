import meggy.Meggy;

class PA5Test6 {

    public static void main(String[] whatever){

			new Class_1().rain((byte)3,(byte)7);

    }
    

}

class Class_1{
	int j;
	int k;
	byte m;
	byte n;
	public void rain( byte a, byte b){
		int i;
		//int j;
		j = 3;
		k = 8;
		m = (byte)9;
		n = (byte)6;
  	}
  
}
