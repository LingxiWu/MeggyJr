import meggy.Meggy;

class PATestLt {
   public static void main(String[] whatever){
		if(1<4){
			Meggy.setPixel((byte)1, (byte)2, Meggy.Color.BLUE );
		}
		if((byte)1<4){
			Meggy.setPixel((byte)2, (byte)3, Meggy.Color.YELLOW );
		}
		if(1<(byte)4){
			Meggy.setPixel((byte)3, (byte)4, Meggy.Color.RED );
		}
		if((byte)1<(byte)4){
			Meggy.setPixel((byte)3, (byte)4, Meggy.Color.RED );
		}
   }
}
