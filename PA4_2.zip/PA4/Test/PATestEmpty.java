import meggy.Meggy;

class PATestEmpty {
   public static void main(String[] whatever){


   }
}
