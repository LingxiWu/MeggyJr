package ast_visitors;

/** 
 * CheckTypes
 * 
 * This AST visitor traverses a MiniJava Abstract Syntax Tree and checks
 * for a number of type errors.  If a type error is found a SymanticException
 * is thrown
 * 
 * CHANGES to make next year (2012)
 *  - make the error messages between *, +, and - consistent <= ??
 *
 * Bring down the symtab code so that it only does get and set Type
 *  for expressions
 */

import ast.node.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;

import symtable.*;
import exceptions.InternalException;
import exceptions.SemanticException;

public class CheckTypes extends DepthFirstVisitor
{
    
   private SymTable mCurrentST;
   
   public CheckTypes(SymTable st) {
     if(st==null) {
          throw new InternalException("unexpected null argument");
      }
      mCurrentST = st;
   }
   
   //========================= Overriding the visitor interface

   public void defaultOut(Node node) {
       System.err.println("Node not implemented in CheckTypes, " + node.getClass());
   }
   
   // program type check.
   public void outProgram(Program node){}
   
   // main class type check.
   public void outMainClass(MainClass node){}
   
   // blocked statement.
   public void outBlockStatement(BlockStatement node){}
   
   // statement type check.
   public void outMeggySetPixel(MeggySetPixel node){
   	   
   	   Type xexpType = mCurrentST.getExpType(node.getXExp());
        Type yexpType = mCurrentST.getExpType(node.getYExp());
        Type colorexpType = mCurrentST.getExpType(node.getColor());
        if ((xexpType==Type.BYTE) &&
            (yexpType==Type.BYTE) &&
            (colorexpType==Type.COLOR)
            ){
            mCurrentST.setExpType(node, Type.VOID);
        } else {
            throw new SemanticException(
                                        "The signature of MeggySetPixel() function is void MeggySetPixel((byte) x, (byte) y, color c)",
                                        node.getXExp().getLine(),
                                        node.getXExp().getPos());
}
   }

   public void outMeggyToneStart(MeggyToneStart node){
   
   		Type toneExpType = mCurrentST.getExpType(node.getToneExp());
   		Type durationExpType = mCurrentST.getExpType(node.getDurationExp());
   		System.out.println(toneExpType);
   		if(toneExpType != Type.TONE){
   			throw new SemanticException("The first param of MeggyToneStart() is type 		 Tone",node.getToneExp().getLine(),node.getToneExp().getLine()); 
   		} 
   		if(durationExpType != Type.INT){
   			throw new SemanticException("The second param of MeggyToneStart() is type 		 Int",node.getToneExp().getLine(),node.getToneExp().getLine());
   		}
   }
   

   
   public void outMeggyDelay(MeggyDelay node){
       Type expType = this.mCurrentST.getExpType(node.getExp());
       if(expType != Type.INT){
           throw new SemanticException("Invalid param type for Meggy Meggy Delay.");
       }
   }
   
   public void outIfStatement(IfStatement node){
       Type expType = this.mCurrentST.getExpType(node.getExp());
       if (expType != Type.BOOL){
           throw new SemanticException(
			"Invalid param type for if statement",
			node.getExp().getLine(), node.getExp().getPos());
       }
   }
   
   public void outWhileStatement(WhileStatement node){
       Type expType = this.mCurrentST.getExpType(node.getExp());
       if(expType !=Type.BOOL){
           throw new SemanticException("Invalid param type for while statement",
           node.getExp().getLine(), node.getExp().getPos());
       }
   }
   
   
   // expression type check.
   public void outAndExp(AndExp node)
   {
   
     Type lexpType = this.mCurrentST.getExpType(node.getLExp());
     Type rexpType = this.mCurrentST.getExpType(node.getRExp());
     
     if(lexpType != Type.BOOL) {
       throw new SemanticException(
         "Left operand for operator && should be bool type",
         node.getLExp().getLine(), node.getLExp().getPos());
     }

     if(rexpType != Type.BOOL) {
       throw new SemanticException(
         "Right operand for operator && should be bool type",
         node.getRExp().getLine(), node.getRExp().getPos());
     }

     this.mCurrentST.setExpType(node, Type.BOOL);
   }
   
   public void outLtExp(LtExp node)
   {
   
     Type lexpType = mCurrentST.getExpType(node.getLExp());
     Type rexpType = mCurrentST.getExpType(node.getRExp());
     
     if(lexpType == Type.INT || lexpType == Type.BYTE) {}
     else{
       throw new SemanticException(
         "Left operand for operator < should be Int or Byte type",
         node.getLExp().getLine(), node.getLExp().getPos());
     }

     if(rexpType == Type.INT || rexpType == Type.BYTE) {}
     else {
       throw new SemanticException(
         "Right operand for operator < should be Int or Byte type",
         node.getRExp().getLine(), node.getRExp().getPos());
     }

     this.mCurrentST.setExpType(node, Type.BOOL);
   }

   public void outEqualExp(EqualExp node)
   {
       Type lexpType = this.mCurrentST.getExpType(node.getLExp());
       Type rexpType = this.mCurrentST.getExpType(node.getRExp());
       if((lexpType==Type.INT  || lexpType==Type.BYTE) &&
           (rexpType==Type.INT  || rexpType==Type.BYTE)){
           this.mCurrentST.setExpType(node, Type.BOOL);
       } else if(lexpType==Type.BUTTON && rexpType==Type.BUTTON){
       	   this.mCurrentST.setExpType(node, Type.BOOL);
       } else if(lexpType==Type.COLOR && rexpType==Type.COLOR){
       	   this.mCurrentST.setExpType(node, Type.BOOL);
       } else {
       	   throw new SemanticException(
                   "Operands to == operator must be INT or BYTE",
                   node.getLExp().getLine(),
                   node.getLExp().getPos());
       }
       
   } 

   public void outPlusExp(PlusExp node)
   {
       Type lexpType = this.mCurrentST.getExpType(node.getLExp());
       Type rexpType = this.mCurrentST.getExpType(node.getRExp());
       if ((lexpType==Type.INT  || lexpType==Type.BYTE) &&
           (rexpType==Type.INT  || rexpType==Type.BYTE)
          ){
           this.mCurrentST.setExpType(node, Type.INT);
       } else {
           throw new SemanticException(
                   "Operands to + operator must be INT or BYTE",
                   node.getLExp().getLine(),
                   node.getLExp().getPos());
       }

   }
   
   public void outMinusExp(MinusExp node){
       Type lexpType = this.mCurrentST.getExpType(node.getLExp());
       Type rexpType = this.mCurrentST.getExpType(node.getRExp());
       if ((lexpType==Type.INT  || lexpType==Type.BYTE) &&
            (rexpType==Type.INT  || rexpType==Type.BYTE)
           ){
            this.mCurrentST.setExpType(node, Type.INT);
        } else {
            throw new SemanticException(
                    "Operands to - operator must be INT or BYTE",
                    node.getLExp().getLine(),
                    node.getLExp().getPos());
		}
   }
   
      public void outMulExp(MulExp node){
         Type lexpType = this.mCurrentST.getExpType(node.getLExp());
         Type rexpType = this.mCurrentST.getExpType(node.getRExp());
		 if(lexpType != Type.INT && lexpType != Type.BYTE) {
		   throw new SemanticException(
		     "Invalid left operand type for operator *",
		     node.getLExp().getLine(), node.getLExp().getPos());
		 }

		 if(rexpType != Type.INT && rexpType != Type.BYTE) {
		   throw new SemanticException(
		     "Invalid right operand type for operator *",
		     node.getRExp().getLine(), node.getRExp().getPos());
		 }

		 this.mCurrentST.setExpType(node, Type.INT);
   	   }
   
  	   public void outNegExp(NegExp node){
           Type expType = this.mCurrentST.getExpType(node.getExp());
           if ((expType==Type.INT  || expType==Type.BYTE)){
               this.mCurrentST.setExpType(node, Type.INT);
           } else {
               throw new SemanticException(
                "Operands to - operator must be INT or BYTE",
                node.getExp().getLine(),
                node.getExp().getPos());
           }
	   }
	   
	   
	    public void outMeggyGetPixel(MeggyGetPixel node){
        	Type xExpType = this.mCurrentST.getExpType(node.getXExp());
        	Type yExpType = this.mCurrentST.getExpType(node.getYExp());
        	
        	if(xExpType == Type.BYTE || xExpType == Type.INT) {
        		if(yExpType == Type.BYTE || yExpType == Type.INT) {
        			this.mCurrentST.setExpType(node, Type.COLOR);
        		} else {
        			throw new SemanticException(
					"Int or Byte type for position y.",
					node.getYExp().getLine(), node.getYExp().getPos());
        		}
        	} else {
        		throw new SemanticException(
					"Int or Byte type for position x.",
					node.getYExp().getLine(), node.getXExp().getPos());
        	}
		}
		
		
	    public void outMeggyCheckButton(MeggyCheckButton node){
        	Type expType = this.mCurrentST.getExpType(node.getExp());
        	if(expType == Type.BUTTON) {
        		this.mCurrentST.setExpType(node, Type.BOOL);
        	} else {
            	throw new SemanticException(
            		"MeggyCheckButton expecting type BUTTON.",
                    node.getExp().getLine(), node.getExp().getPos());
        	}
		}	
			
		public void outByteCast(ByteCast node){
			Type expType = this.mCurrentST.getExpType(node.getExp());
			if (expType==Type.INT  || expType==Type.BYTE){
            	this.mCurrentST.setExpType(node, Type.BYTE);
        	} else {
            throw new SemanticException("Operand to byte cast must be INT or BYTE",
                      node.getExp().getLine(), node.getExp().getPos());
			}
		}
		
		public void outIntegerExp(IntLiteral node){
            this.mCurrentST.setExpType(node, Type.INT);
		}
		
	    public void outColorExp(ColorLiteral node){
	    
        	this.mCurrentST.setExpType(node, Type.COLOR);
		}
		
		public void outButtonExp(ButtonLiteral node){
        	this.mCurrentST.setExpType(node, Type.BUTTON);
		}
		
		public void outToneExp(ToneLiteral node){
   			this.mCurrentST.setExpType(node, Type.TONE);
   		}
		
		public void outTrueExp(TrueLiteral node){
        	this.mCurrentST.setExpType(node, Type.BOOL);
		}
		
	    public void outFalseExp(FalseLiteral node){
        	this.mCurrentST.setExpType(node, Type.BOOL);
		}	
		
		public void outNotExp(NotExp node){
			Type expType = this.mCurrentST.getExpType(node.getExp());
			
		    if(expType != Type.BOOL){
		        throw new SemanticException("Expression must be type Boolean",
		                  node.getExp().getLine(), node.getExp().getPos());
		    } else {
		        this.mCurrentST.setExpType(node, Type.BOOL);
		    }
		}
		
		
		////////////////
		public void inTopClassDecl(TopClassDecl node){
			System.out.println("CheckTyes.inTopClassDecl(" + node.getName() + ") ... ");
			mCurrentST.pushScope(node.getName());
			System.out.println("after push, scope is like this: "+mCurrentST.mScopeStack + "\n");
		}
		
		public void outTopClassDecl(TopClassDecl node){
			System.out.println("in CheckTyes.outTopClassDecl(" + node.getName() + ") ... ");
        	mCurrentST.popScope();
        	System.out.println("after pop, scope is like this: "+mCurrentST.mScopeStack + "\n");
		}
		
		public void inMethodDecl(MethodDecl node){
			System.out.println("in CheckTyes.inMethodDecl(" + node.getName() + ") ... ");
			mCurrentST.pushScope(node.getName());
			System.out.println("after push, scope is like this: "+mCurrentST.mScopeStack + "\n");
			
		}
		
		public void outMethodDecl(MethodDecl node){
			System.out.println("in CheckTyes.outMethodDecl(" + node.getName() + ") ... ");
			// if func has void return type, then it has no return expression
			if (node.getExp() == null){
				mCurrentST.setExpType(node.getExp(), Type.VOID);
			} 
			// func type has to match its ret exp type.
			Type funcType = BuildSymTable.convertType(node.getType());
			Type retExpType = mCurrentST.getExpType(node.getExp());
			if(funcType != retExpType){
				throw new SemanticException("Function " + node.getName() + " has mismatched return 												type",node.getLine(),node.getPos());
			} else if (funcType == retExpType){
				this.mCurrentST.setExpType(node, funcType);
			}
			
			mCurrentST.popScope();
			System.out.println("after pop, scope is like this: "+mCurrentST.mScopeStack + "\n");
		}
		
		public void outFormal(Formal node){
			mCurrentST.setExpType(node, BuildSymTable.convertType(node.getType()));
		}
		
		
		public void outCallStatement(CallStatement node){
			System.out.println("in CheckTyes.outCallStatement(" + node.getId() + ") ... ");
			
			// First, associate node w/ type
			//mCurrentST.setExpType(node,
			
			System.out.println("------------"+node.getExp());
			
		
			
		}
		
		public void outCallExp(CallExp node){
		/*	if(node!=null){
			
			}
		*/	
		}
		
	public void outVoidType(VoidType node){
        mCurrentST.setExpType(node, Type.VOID);
	}
	
	public void outByteType(ByteType node){
        mCurrentST.setExpType(node, Type.BYTE);
	}
	public void outIntType(IntType node){
        mCurrentST.setExpType(node, Type.INT);
    }
    
    public void outBoolType(BoolType node){
        mCurrentST.setExpType(node, Type.BOOL);
    }
    
    public void outColorType(ColorType node){
    
        mCurrentST.setExpType(node, Type.COLOR);
    }
    
    public void outButtonType(ButtonType node){
        mCurrentST.setExpType(node, Type.BUTTON);
    }
    
    public void outToneType(ToneType node){
        mCurrentST.setExpType(node, Type.TONE);
	}
	
	public void outClassType(ClassType node){
		System.out.println("in CheckTypes.outClassType(" + node.toString() + ")");
		System.out.println(Type.getClassType(node.getName()));
        mCurrentST.setExpType(node, Type.getClassType(node.getName()));
	}
	
	// todo: varDEcl
	
	public void outNewExp(NewExp node){
		System.out.println("in CheckTypes.outNewExp(" + node.getId() + ")");
		System.out.println(node.toString());
		/*System.out.println("++++++++++++++++++++++" + node.getId());
		System.out.println("++++++++++++++++++++++" + Type.getClassType(node.getId()));
		
		retrieveClassType(node.getId());
		
		System.out.println(Type.classTypes.size());
		
		for(String name: Type.classTypes.keySet()){
			String key =name.toString();
			String value = Type.classTypes.get(name).toString();
			System.out.println(key + " " + value);
		}
		
		mCurrentST.setExpType(node, Type.getClassType(node.getId()));*/
		mCurrentST.setExpType(node, Type.getClassType(node.getId()));
	}
	
	public void outIdLiteral(IdLiteral node){
		System.out.println("in CheckTypes.outIdLiteral(" + node.toString() + ")");
		VarSTE varSte = (VarSTE)mCurrentST.lookup(node.toString());
		if (varSte == null){
            this.mCurrentST.setExpType(node, Type.VOID);
		} else {
			mCurrentST.setExpType(node, varSte.getType());
		}
	}

		




    

		

	   



  

}
