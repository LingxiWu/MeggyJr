package symtable;

import symtable.Type;
import java.util.*;
public class Signature{
	private Type returnType;
	private LinkedList<Type> formalTyps_list;
	
	public Signature(Type returnType, LinkedList<Type> formalTyps_list){
		this.returnType = returnType;
		this.formalTyps_list = formalTyps_list;
	}
	
	public LinkedList<Type> getFormals(){
		return formalTyps_list;
	}

	
}
