
import meggy.Meggy;

class PATest {

    public static void main(String[] whatever){
			new Cloud().rain((byte)3,(byte)7);
			new Loud().raind();
    }
    

}

class Cloud{
	public void rain( byte a, byte b){
    	Meggy.setPixel(a, b, Meggy.Color.BLUE);
  	}
  	
}
class Loud{
	public void raind(){
	
	}
}



