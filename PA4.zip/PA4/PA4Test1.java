/**
 * PA4Test1.java
 * Testing function calls set yellow and blue.
 */

import meggy.Meggy;

class PA4Test1 {

    public static void main(String[] args){
        {   
			while(true){
				Meggy.setPixel((byte)1, (byte)2, Meggy.Color.RED);
			    Meggy.delay(1000);

				new Utility().setYellow(Meggy.Color.YELLOW);
			    Meggy.delay(3000-2000);
						
			    Meggy.setPixel((byte)1, (byte)2, Meggy.Color.RED);
			    Meggy.delay(1000+(1000-1000));
			}
        }
    }


}

class Utility {
    public void setYellow(Meggy.Color color) {
		if(Meggy.getPixel((byte)1, (byte)2) == Meggy.Color.RED){
			Meggy.setPixel((byte)1, (byte)2, color);
		}
    }	
}

