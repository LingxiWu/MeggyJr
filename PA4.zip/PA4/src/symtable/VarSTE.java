package symtable;

public class VarSTE extends STE{

	private Type mType;
	private int mOffset;
	private String mBase; // ?
	
	public VarSTE(String mName, Type mType){
		super(mName);
		this.mType = mType;
		this.mBase = "Y"; // Y for local variable I guess ...
	}		
	
	public VarSTE(String mName, Type mType, int mOffset){
		super(mName);
		this.mType = mType;
		this.mBase = "Y"; // Y for local variable I guess ...
		this.mOffset = mOffset;
	}	
	
	public Type getType(){
		return mType;
	}
	
	public int getOffset(){
		return mOffset;
	}
	
	public String getBase(){
		return mBase;
	}

	
	// setLocation(base, offset)
	// getBase()
	// getOffset()
	// isMember()
	// isParam()
	// isLocal()
	

}
