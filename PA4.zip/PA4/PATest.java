
import meggy.Meggy;

class PATest {

    public static void main(String[] whatever){
			new Class_1().storm(3,7);
			new Class_1().rain((byte)3,(byte)7);
			new Class_2().wind();
    }
    

}

class Class_1{
	public void rain( byte a, byte b){
    	Meggy.setPixel(a, b, Meggy.Color.BLUE);
  }
  
  public int storm(int c, int d){
  	return c + d;
  }
  	
}
class Class_2{
	public void wind(){
	
	}
}
