Name: Lingxi Wu
Computing ID: lw2ef

To make PA4 compiler, in PA4/PA4 type in "make clean;make"
To test any cases, type "java -jar MJ.jar PATest.java"

To test batch files, in /Test, type in ./regress.sh

in PA4/PA4 there are PA4Test1.java, PA4Test2.java, PA4Test3.java and PA4raindrop.java, PA4Mazesolver.java, PA4bluedot.java. 
