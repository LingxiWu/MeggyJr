import meggy.Meggy;

class ErrorSetPixel {
       public static void main(String[] args){
               Meggy.setPixel(6, 5, Meggy.Color.YELLOW);
       }
}
