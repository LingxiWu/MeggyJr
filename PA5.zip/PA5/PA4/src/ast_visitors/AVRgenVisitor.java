package ast_visitors;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;
import java.util.ListIterator;

import exceptions.SemanticException;
import exceptions.InternalException;
import label.Label;

import symtable.*;
import ast.visitor.DepthFirstVisitor;
import ast.node.*;
import java.util.*;

public class AVRgenVisitor extends DepthFirstVisitor {

	private PrintWriter pout;
	private SymTable symTbl;
	
	// constructor.
	public AVRgenVisitor(PrintWriter pw, SymTable st){
		pout = pw;
		if(st==null) {
          throw new InternalException("symTbl null");
      	}
      	symTbl = st;
	}

	public void inProgram(Program node){
		InputStream mainPrologue=null;
        BufferedReader reader=null;
        try {
            System.out.println("Generate prolog using avrH.rtl.s");
            mainPrologue 
                    = this.getClass().getClassLoader().getResourceAsStream(
                        "avrH.rtl.s");
            reader = new BufferedReader(new InputStreamReader(mainPrologue));
            String line = null;
            while ((line = reader.readLine()) != null) {
            	pout.println(line);
            }
            pout.println("\n");
            } catch ( Exception e2) {
                e2.printStackTrace();
            }
            finally{
            	try{
                    if(mainPrologue!=null) mainPrologue.close();
                    if(reader!=null) reader.close();
                }
                catch (IOException e) {
                   e.printStackTrace();
                }
            }
	} 
	
	public void outMainClass(MainClass node){
		InputStream mainEpilogue=null;
        BufferedReader reader=null;
        try {
            System.out.println("Generate Epilog using avrF.rtl.s");
            mainEpilogue 
                    = this.getClass().getClassLoader().getResourceAsStream(
                        "avrF.rtl.s");
            reader = new BufferedReader(new InputStreamReader(mainEpilogue));
            String line = null;
            while ((line = reader.readLine()) != null) {
            	pout.println(line);
            }
            pout.println("\n");
            } catch ( Exception e2) {
                e2.printStackTrace();
            }
            finally{
            	try{
                    if(mainEpilogue!=null) mainEpilogue.close();
                    if(reader!=null) reader.close();
                }
                catch (IOException e) {
                   e.printStackTrace();
                }
            }
	}


	
	public void outProgram(Program node){	
            pout.flush();
	}

	public void inTopClassDecl(TopClassDecl node){
		System.out.println("\nin AVRGenVisitor.inTopClassDecl(" + node.getName() + ") ... ");
		System.out.println("make class " + node.getName() + " the top of scope stack");
		symTbl.pushScope(node.getName());
		System.out.println("after push, scope is like this: "+symTbl.mScopeStack);

	}

	public void outTopClassDecl(TopClassDecl node){
		System.out.println("\nin AVRGenVisitor.outTopClassDecl(" + node.getName() + ") ... ");
		System.out.println("pop top of the scope stack");
		symTbl.popScope();
		System.out.println("after pop, scope is like this: "+symTbl.mScopeStack);
	}
	
	public void inMethodDecl(MethodDecl node){
		System.out.println("\nin AVRGenVisitor.inMethodDecl(" + node.getName() + ") ... ");
		
		// make current func on top of stack for processing.
		symTbl.pushScope(node.getName());
		
		// get class name by looking at the "this"
		Scope methodScope = symTbl.peekScopeStack();
		String className = ((VarSTE)methodScope.mDict.get("this")).getType().toString();
		String funcName = className + "_" + node.getName();
		// get class name by get to its mScope
		System.out.println("after push, scope is like this: "+symTbl.mScopeStack);
		
		pout.println("/*prologue start for function " + funcName + "*/\n" +
		             ".text\n" + ".global " + funcName + "\n" + 
		             ".type " + funcName + ", @function\n" + funcName +
		             ":\n");
		pout.println("push r29");
		pout.println("push r28");
		pout.println("# make space for locals and params");
		pout.println("ldi	r30, 0");
		pout.println("push	r30");
		pout.println("push	r30");
		
		// loop through method locals and reserve space
		LinkedList<VarDecl> var_list = node.getVarDecls();
		Iterator node_itr_3 = var_list.iterator();
		
		while(node_itr_3.hasNext()){
			IType it = ((VarDecl)node_itr_3.next()).getType();
			int var_size = BuildSymTable.convertType(it).getAVRTypeSize();
			if(var_size == 1){
				pout.println("push	r30");	
			} else if (var_size == 2){
				pout.println("push	r30");	
				pout.println("push	r30");	
			}
		}

		// loop through formals and reserve space
		LinkedList<Formal> formal_list = node.getFormals();
		Iterator node_itr_1 = formal_list.iterator();
		while(node_itr_1.hasNext()){
			IType it = ((Formal)node_itr_1.next()).getType();	
			int formal_size = BuildSymTable.convertType(it).getAVRTypeSize();
			if(formal_size == 1){
				pout.println("push	r30");	
			} else if (formal_size == 2){
				pout.println("push	r30");	
				pout.println("push	r30");	
			}
		}
		pout.println("\n# Copy stack pointer to frame pointer");
		pout.println("in	r28,__SP_L__");
		pout.println("in	r29,__SP_H__\n");

		pout.println("# save off parameters");
		pout.println("std	Y + 2, r25");	
		pout.println("std	Y + 1, r24");	             
		// prepare register in reverse order starting from r23
		Iterator node_itr_2 = formal_list.iterator();
		int r = 24, y = 3, max_y = y;
		String register = "";
		while(node_itr_2.hasNext()){
			IType it = ((Formal)node_itr_2.next()).getType();	
			int formal_size = BuildSymTable.convertType(it).getAVRTypeSize();
			if(formal_size == 1){
				max_y += 1;
				y = max_y;
				y -= 1;				
				r -= 2;
				pout.println("std	Y + " + y + ", r" + r); 
			} else if (formal_size == 2){
				max_y += 1;
				y = max_y;
				r -= 1;
				pout.println("std	Y + " + y + ", r" + r);  
				y -= 1;
				r -= 1;
				pout.println("std	Y + " + y + ", r" + r); 
				max_y += 1;
			}
		}
		
		pout.println("\n/* done with function "+funcName+" prologue */\n\n");		
	}
	
	public void outMethodDecl(MethodDecl node){
		System.out.println("\nin AVRGenVisitor.outMethodDecl(" + node.getName() + ") ... ");
		System.out.println("pop top of the scope stack");
	
		// get class name by looking at the "this"
		Scope methodScope = symTbl.peekScopeStack();
		String className = ((VarSTE)methodScope.mDict.get("this")).getType().toString();
		String funcName = className + "_" + node.getName();
		
		pout.println("/* epilogue start for " + funcName + "*/");
		
		if(node.getExp() != null){ // requires return
			// have to determine the size of return type
			Type retType = BuildSymTable.convertType(node.getType());
			System.out.println(BuildSymTable.convertType(node.getType()));
			pout.println("# handle return value");
			if(retType.getAVRTypeSize() == 2){				
				pout.println("# load a two byte expression off stack");
				pout.println("pop    r24");
				pout.println("pop    r25");
			} else if (retType.getAVRTypeSize() == 1){
				String MJ_L0 = new Label().toString();
				String MJ_L1 = new Label().toString();
				pout.println("# load a one byte expression off stack");
				pout.println("pop    r24");
				pout.println("# promoting a byte to an int");
				pout.println("tst     r24");
				pout.println("brlt     " + MJ_L0); // MJ_L0
				pout.println("ldi    r25, 0");
				pout.println("jmp    " + MJ_L1); // MJ_L1
				pout.println(MJ_L0 + ":"); // MJ_L0
				pout.println("ldi    r25, hi8(-1)");
				pout.println(MJ_L1 + ":"); // MJ_L1
			}
		} else { // void return
			pout.println("# no return value");
			pout.println("# pop space off stack for parameters and locals");			
		}
		pout.println("pop	r30");
		pout.println("pop	r30");
		
		// loop through locals and pop
		LinkedList<VarDecl> var_list = node.getVarDecls();
		Iterator node_itr_2 = var_list.iterator();
		while(node_itr_2.hasNext()){
			IType it = ((VarDecl)node_itr_2.next()).getType();	
			int var_size = BuildSymTable.convertType(it).getAVRTypeSize();
			if(var_size == 1){
				pout.println("pop	r30");	
			} else if (var_size == 2){
				pout.println("pop	r30");	
				pout.println("pop	r30");	
			}
		}
		// loop through formals and pop
		LinkedList<Formal> formal_list = node.getFormals();
		Iterator node_itr_1 = formal_list.iterator();
		while(node_itr_1.hasNext()){
			IType it = ((Formal)node_itr_1.next()).getType();	
			int formal_size = BuildSymTable.convertType(it).getAVRTypeSize();
			if(formal_size == 1){
				pout.println("pop	r30");	
			} else if (formal_size == 2){
				pout.println("pop	r30");	
				pout.println("pop	r30");	
			}
		}
		
		pout.println("\n"+
                        "# restoring the frame pointer\n"+
                        "pop	r28\n"+
                        "pop	r29\n\n" +
                        "ret\n"+
".size " + funcName + ", .-" + funcName + "\n\n");
		
		symTbl.popScope();
		System.out.println("after pop, scope is like this: "+symTbl.mScopeStack);
	}
		public void outCallExp(CallExp node){
	
		System.out.println("\nin AVRGenVisitor.outCallExp(" + node.getId() + ") ... ");
		System.out.println(node.getExp());
		// determine class/type
		String class_name = symTbl.getExpType(node.getExp()).toString();
		//String class_name = Type.
		LinkedList<IExp> argList = node.getArgs();
		ListIterator<IExp> iter = argList.listIterator(argList.size());
		IExp arg;
		int reg = 24 - 2*argList.size(); // initial reg num. if #arg = 3, then start with r18 (24-2*3)
		while(iter.hasPrevious()){
			arg = iter.previous();
			System.out.println(arg);
			int argSize = symTbl.getExpType(arg).getAVRTypeSize();
			symTbl.getExpType(arg);
			if(argSize == 1){
				pout.println("# load a one byte expression off stack");
				pout.println("pop	r"+reg);
				reg += 2;
			} else if(argSize == 2){
				pout.println("pop	r"+reg);
				reg += 1;
				pout.println("pop	r"+reg);
				reg += 1;
			}
		}
		
		pout.println("# receiver will be passed as first param");
		pout.println("# load a two byte expression off stack");
		pout.println("pop	r24");
		pout.println("pop	r25\n");
		//pout.println("call	" + funcName);
		pout.println("call	" + class_name + "_" + node.getId());

		// handle returns
		Type retType = symTbl.getExpType(node);
		if (retType != Type.VOID && retType != null){
			pout.println("# handle return value\n");
			if(retType.getAVRTypeSize() == 2){
				pout.println("push	r25\n");
			}
			pout.println("push	r24");
		}   
	}
	
	public void outCallStatement(CallStatement node){
	
		System.out.println("\nin AVRGenVisitor.outCallStatement(" + node.getId() + ") ... ");
		System.out.println(node.getExp());
		// determine class/type
		String class_name = symTbl.getExpType(node.getExp()).toString();
		//String class_name = Type.
		LinkedList<IExp> argList = node.getArgs();
		ListIterator<IExp> iter = argList.listIterator(argList.size());
		IExp arg;
		int reg = 24 - 2*argList.size(); // initial reg num. if #arg = 3, then start with r18 (24-2*3)
		while(iter.hasPrevious()){
			arg = iter.previous();
			System.out.println(arg);
			int argSize = symTbl.getExpType(arg).getAVRTypeSize();
			symTbl.getExpType(arg);
			if(argSize == 1){
				pout.println("# load a one byte expression off stack");
				pout.println("pop	r"+reg);
				reg += 2;
			} else if(argSize == 2){
				pout.println("# load a two byte expression off stack");
				pout.println("pop	r"+reg);
				reg += 1;
				pout.println("pop	r"+reg);
				reg += 1;
			}
		}
		
		pout.println("# receiver will be passed as first param");
		pout.println("# load a two byte expression off stack");
		pout.println("pop	r24");
		pout.println("pop	r25\n");
		//pout.println("call	" + funcName);
		pout.println("call	" + class_name + "_" + node.getId());

		// handle returns
		Type retType = symTbl.getExpType(node);
		if (retType != Type.VOID && retType != null){
			pout.println("# handle return value\n");
			if(retType.getAVRTypeSize() == 2){
				pout.println("push	r25\n");
			}
			pout.println("push	r24");
		}   
	}

	// statements code gen
	/* if statement */
	public void inIfStatement(IfStatement node){
        pout.println("#### if statement");
        pout.println("");
	}
	
	public void visitIfStatement(IfStatement node){
		inIfStatement(node);
		String branch_then = new Label().toString();
        String branch_else = new Label().toString();
		String branch_done = new Label().toString();
        if(node.getExp() != null)
        {
            node.getExp().accept(this);
        }
        pout.println("# load condition and branch if false");
        pout.println("# load a one byte expression off stack");
        pout.println("pop    r24");
        pout.println("#load zero into reg");
        pout.println("ldi    r25, 0\n");
        pout.println("#use cp to set SREG");
        pout.println("cp     r24, r25");
        pout.println("#WANT breq " + branch_else); // branch_else
        pout.println("brne   " + branch_then); // branch_then
        pout.println("jmp    " + branch_else + "\n"); // branch_else
        pout.println("# then label for if");
        pout.println(branch_then + ":"); // branch_then
        pout.println("");
        
        if(node.getThenStatement() != null)
        {
            node.getThenStatement().accept(this);
        }
        pout.println("jmp    " + branch_done); // branch_done
        pout.println("\n# else label for if"); 
        pout.println(branch_else + ":"); // branch_else
        pout.println("");
        
        if(node.getElseStatement() != null)
        {
            node.getElseStatement().accept(this);
        }
        pout.println("# done label for if");
        pout.println(branch_done + ":"); // branch_done
        pout.println("");
        
        outIfStatement(node);
	}
		
	public void outMeggyDelay(MeggyDelay node){
		pout.println("### Meggy.delay() call");
		pout.println("# load delay parameter");
		pout.println("# load a two byte expression off stack");
		pout.println("pop    r24");
		pout.println("pop    r25");
		pout.println("call   _Z8delay_msj");
		pout.println("");
	}
	
	public void outMeggySetPixel(MeggySetPixel node){
		pout.println("### Meggy.setPixel(x,y,color) call");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r20");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r22");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r24");
		pout.println("call   _Z6DrawPxhhh");
		pout.println("call   _Z12DisplaySlatev");
		pout.println("");
	}
	
	public void outMeggyGetPixel(MeggyGetPixel node){
		pout.println("### Meggy.getPixel(x,y) call");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r22");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r24");
		pout.println("call   _Z6ReadPxhh");
		pout.println("# push one byte expression onto stack");
		pout.println("push   r24");
		pout.println("");
	}
	
	/* while statement */
	public void inWhileStatement(WhileStatement node){
        pout.println("#### while statement\n");
	}
	public void visitWhileStatement(WhileStatement node){
	
		String branch_start = new Label().toString();
		String branch_body = new Label().toString();
		String branch_end = new Label().toString();
		
		inWhileStatement(node);
		pout.println(branch_start + ":");
        if(node.getExp() != null)
        {
            node.getExp().accept(this);
        }
        // loop body
        pout.println("# if not(condition)");
        pout.println("# load a one byte expression off stack");
        pout.println("pop    r24");
        pout.println("ldi    r25,0");
        pout.println("cp     r24, r25");
        pout.println("# WANT breq " + branch_end); // branch_end
        pout.println("brne   " + branch_body); // branch_body
        pout.println("jmp    " + branch_end); // branch_end
        pout.println("# while loop body");
        pout.println(branch_body + ":"); // branch_body
        pout.println("");
        if(node.getStatement() != null)
        {
            node.getStatement().accept(this);
        }
        pout.println("# jump to while test");
        pout.println("jmp    " + branch_start); // branch_start
        pout.println("# end of while");
        pout.println(branch_end + ":"); // branch_end
        pout.println("");

        outWhileStatement(node);	
	}

	// expression code gen
	public void outByteCast(ByteCast node){
		Type expType = this.symTbl.getExpType(node.getExp());
		if(expType == Type.BYTE){
			return; // skip casting
		}
		pout.println("# Casting int to byte by popping");
		pout.println("# 2 bytes off stack and only pushing low order bits");
		pout.println("# back on.  Low order bits are on top of stack.");
		pout.println("pop    r24");
		pout.println("pop    r25");
		pout.println("push   r24");
		pout.println("");
	}
	
	public void outIntegerExp(IntLiteral node){
		int value = node.getIntValue();
		pout.println("# Load constant int" + value);
		pout.println("ldi    r24,lo8("+value+")");
		pout.println("ldi    r25,hi8("+value+")");
		pout.println("# push two byte expression onto stack");
		pout.println("push   r25");
		pout.println("push   r24");
		pout.println("");
	}
	
	public void outMinusExp(MinusExp node){
	    String branch_1 = new Label().toString();
		String branch_2 = new Label().toString();
		String branch_3 = new Label().toString();
		String branch_4 = new Label().toString();
		// minus all int routine.
		if(symTbl.getExpType(node.getLExp()) == Type.INT && 
			symTbl.getExpType(node.getRExp()) == Type.INT){
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r18");
			pout.println("pop    r19");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("");
			pout.println("# Do INT sub operation");
			pout.println("sub    r24, r18");
			pout.println("sbc    r25, r19");
			pout.println("# push hi order byte first");
			pout.println("# push two byte expression onto stack");
			pout.println("push   r25");
			pout.println("push   r24");
			pout.println("");
    	} 	
    	// minus all byte routine.		
    	else if(symTbl.getExpType(node.getLExp()) == Type.BYTE && 
    		symTbl.getExpType(node.getRExp()) == Type.BYTE){
    		pout.println("# load a one byte expression off stack");
    		pout.println("pop    r18");
    		pout.println("# load a one byte expression off stack");
    		pout.println("pop    r24");
    		pout.println("# promoting a byte to an int");
    		pout.println("tst     r24");
    		pout.println("brlt     " + branch_1); //MJ_L1
    		pout.println("ldi    r25, 0");
    		pout.println("jmp    " + branch_2); //MJ_L2
    		pout.println(branch_1 + ":"); //MJ_L1
    		pout.println("ldi    r25, hi8(-1)");
    		pout.println(branch_2 + ":"); //MJ_L2
    		pout.println("# promoting a byte to an int");
    		pout.println("tst     r18");
    		pout.println("brlt     " + branch_3); //MJ_L3
    		pout.println("ldi    r19, 0");
    		pout.println("jmp    " + branch_4); //MJ_L4
    		pout.println(branch_3 + ":"); //MJ_L3
    		pout.println("ldi    r19, hi8(-1)");
    		pout.println(branch_4 + ":"); //MJ_L4
    		pout.println("");
    		pout.println("# Do INT sub operation");
    		pout.println("sub    r24, r18");
    		pout.println("sbc    r25, r19");
    		pout.println("# push hi order byte first");
    		pout.println("# push two byte expression onto stack");
    		pout.println("push   r25");
    		pout.println("push   r24");
    		pout.println("");
    	}
    	// first byte second int
    	else if(symTbl.getExpType(node.getLExp()) == Type.BYTE && 
    		symTbl.getExpType(node.getRExp()) == Type.INT){
    		pout.println("# load a two byte expression off stack");
    		pout.println("pop    r18");
    		pout.println("pop    r19");
    		pout.println("# load a one byte expression off stack");
    		pout.println("pop    r24");
    		pout.println("# promoting a byte to an int");
    		pout.println("tst     r24");
    		pout.println("brlt     " + branch_1); // branch_1
    		pout.println("ldi    r25, 0");
    		pout.println("jmp    " + branch_2); // branch_2
    		pout.println(branch_1 + ":"); // branch_1
    		pout.println("ldi    r25, hi8(-1)");
    		pout.println(branch_2 + ":"); // branch_2
    		pout.println("# Do INT sub operation");
    		pout.println("sub    r24, r18");
    		pout.println("sbc    r25, r19");
    		pout.println("# push hi order byte first");
    		pout.println("# push two byte expression onto stack");
    		pout.println("push   r25");
    		pout.println("push   r24");
    		pout.println("");
    	}
    	// first int second byte
    	else if(symTbl.getExpType(node.getLExp()) == Type.INT && 
    		symTbl.getExpType(node.getRExp()) == Type.BYTE){
    		pout.println("# load a one byte expression off stack");
    		pout.println("pop    r18");
    		pout.println("# load a two byte expression off stack");
    		pout.println("pop    r24");
    		pout.println("pop    r25");
    		pout.println("# promoting a byte to an int");
    		pout.println("tst     r18");
    		pout.println("brlt     " + branch_1); // branch_1
    		pout.println("ldi    r19, 0"); 
    		pout.println("jmp    " + branch_2); // branch_2
    		pout.println(branch_1 + ":"); // branch_1
    		pout.println("ldi    r19, hi8(-1)");
    		pout.println(branch_2 + ":"); // branch_2
    		pout.println("");
    		pout.println("# Do INT sub operation");
    		pout.println("sub    r24, r18");
    		pout.println("sbc    r25, r19");
    		pout.println("# push hi order byte first");
    		pout.println("# push two byte expression onto stack");
    		pout.println("push   r25");
    		pout.println("push   r24");
    		pout.println("");
    	}
	}
	
	public void outMulExp(MulExp node){
		// for some reason, the reference MJ parser only support byte type multiplication.	
		pout.println("# MulExp");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r18");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r22");
		pout.println("# move low byte src into dest reg");
		pout.println("mov    r24, r18");
		pout.println("# move low byte src into dest reg");
		pout.println("mov    r26, r22");
		pout.println("# Do mul operation of two input bytes");
		pout.println("muls   r24, r26");
		pout.println("# push two byte expression onto stack");
		pout.println("push   r1");
		pout.println("push   r0");
		pout.println("# clear r0 and r1");
		pout.println("eor    r0,r0");
		pout.println("eor    r1,r1");
		pout.println("");
	}
	
	public void outPlusExp(PlusExp node){
		// all int routine
	    String branch_1 = new Label().toString();
		String branch_2 = new Label().toString();
		String branch_3 = new Label().toString();
		String branch_4 = new Label().toString();
		if(symTbl.getExpType(node.getLExp()) == Type.INT && 
			symTbl.getExpType(node.getRExp()) == Type.INT){
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r18");
			pout.println("pop    r19");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("# Do add operation");
			pout.println("add    r24, r18");
			pout.println("adc    r25, r19");
			pout.println("# push two byte expression onto stack");
			pout.println("push   r25");
			pout.println("push   r24");
			pout.println("");
		}
		// all byte routine
		else if(symTbl.getExpType(node.getLExp()) == Type.BYTE && 
    		symTbl.getExpType(node.getRExp()) == Type.BYTE){
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r18");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r24");
			pout.println("# promoting a byte to an int");
			pout.println("tst     r24");
			pout.println("brlt     " + branch_1); // branch_1
			pout.println("ldi    r25, 0");
			pout.println("jmp    " + branch_2); // branch_2
			pout.println(branch_1 + ":"); // branch_1
			pout.println("ldi    r25, hi8(-1)");
			pout.println(branch_2 + ":"); // branch_2
			pout.println("# promoting a byte to an int");
			pout.println("tst     r18");
			pout.println("brlt     " + branch_3); // branch_3
			pout.println("ldi    r19, 0");
			pout.println("jmp    " + branch_4); // branch_4
			pout.println(branch_3 + ":"); // branch_3
			pout.println("ldi    r19, hi8(-1)");
			pout.println(branch_4 + ":");	// branch_4
			pout.println("# Do add operation");
			pout.println("add    r24, r18");
			pout.println("adc    r25, r19");
			pout.println("# push two byte expression onto stack");
			pout.println("push   r25");	
			pout.println("push   r24");
			pout.println("");	

		}
		// first byte second int
		else if(symTbl.getExpType(node.getLExp()) == Type.BYTE && 
    		symTbl.getExpType(node.getRExp()) == Type.INT){
    		pout.println("# load a two byte expression off stack");
    		pout.println("pop    r18");
    		pout.println("pop    r19");
    		pout.println("# load a one byte expression off stack");
    		pout.println("pop    r24");
    		pout.println("# promoting a byte to an int");
    		pout.println("tst     r24");
    		pout.println("brlt     " + branch_1); // branch_1
    		pout.println("ldi    r25, 0");
    		pout.println("jmp    " + branch_2); // branch_2
    		pout.println(branch_1 + ":"); // branch_1
    		pout.println("ldi    r25, hi8(-1)");
    		pout.println(branch_2 + ":"); // branch_2
    		pout.println("# Do add operation");
    		pout.println("add    r24, r18");
    		pout.println("adc    r25, r19");
    		pout.println("# push two byte expression onto stack");
    		pout.println("push   r25");
    		pout.println("push   r24");
    		pout.println("");
		}
		// first int second byte
		else if(symTbl.getExpType(node.getLExp()) == Type.INT && 
    		symTbl.getExpType(node.getRExp()) == Type.BYTE){
    		pout.println("# load a one byte expression off stack");
    		pout.println("pop    r18");
    		pout.println("# load a two byte expression off stack");
    		pout.println("pop    r24");
    		pout.println("pop    r25");
    		pout.println("# promoting a byte to an int");
    		pout.println("tst     r18");
    		pout.println("brlt     " + branch_1); // branch_1
    		pout.println("ldi    r19, 0");
    		pout.println("jmp    " + branch_2); // branch_2
    		pout.println(branch_1 + ":"); // branch_1
    		pout.println("ldi    r19, hi8(-1)");
    		pout.println(branch_2 + ":"); // branch_2
    		pout.println("# Do add operation");
    		pout.println("add    r24, r18");
    		pout.println("adc    r25, r19");
    		pout.println("# push two byte expression onto stack");
    		pout.println("push   r25");
    		pout.println("push   r24");
    		pout.println("");
		}
	}
	
	public void outNegExp(NegExp node){
		// negate int routine.
		Type expType = this.symTbl.getExpType(node.getExp());
		if(expType == Type.INT){
			pout.println("# neg int");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("ldi     r22, 0");
			pout.println("ldi     r23, 0");
			pout.println("sub     r22, r24");
			pout.println("sbc     r23, r25");
			pout.println("# push two byte expression onto stack");
			pout.println("push   r23");
			pout.println("push   r22");
			pout.println("");
		} 
		// negate byte routine.
		else if (expType == Type.BYTE){
		
			String branch_1 = new Label().toString();
			String branch_2 = new Label().toString();
			String branch_3 = new Label().toString();
			
			pout.println("# neg byte");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r24");
			pout.println("# promoting a byte to an int");
			pout.println("tst     r24");
			pout.println("brlt     " + branch_1);// branch 1
			pout.println("ldi    r25, 0");
			pout.println("jmp    " + branch_2); // branch 2
			pout.println(branch_1 + ":"); // branch 1
			pout.println("ldi    r25, hi8(-1)");
			pout.println(branch_2 + ":"); // branch 2
			pout.println("ldi    r22, 0");
			pout.println("ldi    r23, 0");
			pout.println("sub     r22, r24");
			pout.println("sbc     r23, r25");
			pout.println("# push two byte expression onto stack");
			pout.println("push   r23");
			pout.println("push   r22");
			pout.println("");
		}
	}
	
	public void outTrueExp(TrueLiteral node){
		pout.println("# True/1 expression");
		pout.println("ldi    r22, 1");
		pout.println("# push one byte expression onto stack");
		pout.println("push   r22");
		pout.println("");
	}
	
	public void outFalseExp(FalseLiteral node){
		pout.println("# False/0 expression");
		pout.println("ldi    r22,0");
		pout.println("# push one byte expression onto stack");
		pout.println("push   r22");
		pout.println("");
	}
	
	/* and exp */ 
	public void inAndExp(AndExp node){
		pout.println("#### short-circuited && operation");
		pout.println("# &&: left operand");
		pout.println("");
	}
	
	
	public void visitAndExp(AndExp node){
		inAndExp(node);
		String right_branch = new Label().toString();
		String done_branch = new Label().toString();
        if(node.getLExp() != null)
        {
            node.getLExp().accept(this);
        }
        pout.println("# &&: if left operand is false do not eval right");
        pout.println("# load a one byte expression off stack");
        pout.println("pop    r24");
        pout.println("# push one byte expression onto stack");
        pout.println("push   r24");
        pout.println("# compare left exp with zero");
        pout.println("ldi r25, 0");
        pout.println("cp    r24, r25");
        pout.println("# Want this, breq done_branch");
        pout.println("brne  " + right_branch); // right_branch
        pout.println("jmp   " + done_branch); // done_branch
        pout.println("");
        if(node.getRExp() != null)
        {
            node.getRExp().accept(this);
        }
        pout.println(right_branch + ":"); // right_branch
        pout.println("# right operand");
        pout.println("# load a one byte expression off stack");
        pout.println("pop    r24");
        pout.println("# True/1 expression");
        pout.println("ldi    r22, 1");
        pout.println("# push one byte expression onto stack");
        pout.println("push   r22");
        pout.println("# load a one byte expression off stack");
        pout.println("pop    r24");
        pout.println("# push one byte expression onto stack");
        pout.println("push   r24");
        pout.println(done_branch + ":"); //done_branch
        pout.println("");

        outAndExp(node);
	}

	
	public void outLtExp(LtExp node){
		Type lexpType = this.symTbl.getExpType(node.getLExp());
		Type rexpType = this.symTbl.getExpType(node.getRExp());
		// int int
		if(lexpType == Type.INT && rexpType == Type.INT){
			String true_branch = new Label().toString();
			String false_branch = new Label().toString();
			String result_branch = new Label().toString();
			
			pout.println("# less than expression");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r18");
			pout.println("pop    r19");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("cp    r24, r18");
			pout.println("cpc   r25, r19");
			pout.println("brlt " + true_branch + "\n"); // true_branch
			pout.println("# load false");
			pout.println(false_branch + ":"); // false_branch
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + result_branch + "\n"); // result_branch
			pout.println("# load true");
			pout.println(true_branch + ":"); // true_branch
			pout.println("ldi    r24, 1\n");
			pout.println("# push result of less than");
			pout.println(result_branch + ":"); // result_branch
			pout.println("# push one byte expression onto stack");
			pout.println("push   r24");
			pout.println("");
		}
		
		// int byte
		if(lexpType == Type.INT && rexpType == Type.BYTE){
			String MJ_L3 = new Label().toString();
			String MJ_L4 = new Label().toString();
			String MJ_L5 = new Label().toString();
			String MJ_L6 = new Label().toString();
			String MJ_L7 = new Label().toString();
			pout.println("# less than expression");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r18");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("# promoting a byte to an int");
			pout.println("tst     r18");
			pout.println("brlt     " + MJ_L6); // MJ_L6
			pout.println("ldi    r19, 0");
			pout.println("jmp    " + MJ_L7); // MJ_L7
			pout.println(MJ_L6 + ":"); // MJ_L6
			pout.println("ldi    r19, hi8(-1)");
			pout.println(MJ_L7 + ":"); // MJ_L7
			pout.println("cp    r24, r18");
			pout.println("cpc   r25, r19");
			pout.println("brlt " + MJ_L4 + "\n"); // MJ_L4
			pout.println("# load false");
			pout.println(MJ_L3 + ":"); // MJ_L3
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + MJ_L5 + "\n"); // MJ_L5
			pout.println("# load true");
			pout.println(MJ_L4 + ":"); // MJ_L4
			pout.println("ldi    r24, 1\n");
			pout.println("# push result of less than");
			pout.println(MJ_L5 + ":"); // MJ_L5
			pout.println("# push one byte expression onto stack");
			pout.println(" push   r24");
			pout.println("");
		}

		// byte int
		if(lexpType == Type.BYTE && rexpType == Type.INT){
			String MJ_L3 = new Label().toString();
			String MJ_L4 = new Label().toString();
			String MJ_L5 = new Label().toString();
			String MJ_L6 = new Label().toString();
			String MJ_L7 = new Label().toString();
			pout.println("# less than expression");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r18");
			pout.println("pop    r19");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r24");
			pout.println("# promoting a byte to an int");
			pout.println("tst     r24");
			pout.println("brlt     " + MJ_L6);
			pout.println("ldi    r25, 0");
			pout.println("jmp    " + MJ_L7);
			pout.println(MJ_L6 + ":");
			pout.println("ldi    r25, hi8(-1)");
			pout.println(MJ_L7 + ":");
			pout.println("cp    r24, r18");
			pout.println("cpc   r25, r19");
			pout.println("brlt " + MJ_L4);
			pout.println("# load false");
			pout.println(MJ_L3 + ":");
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + MJ_L5);
			pout.println("# load true");
			pout.println(MJ_L4 + ":");
			pout.println("ldi    r24, 1");
			pout.println("# push result of less than");
			pout.println(MJ_L5 + ":");
			pout.println("# push one byte expression onto stack");
			pout.println(" push   r24");
			pout.println("");

		}
		// byte byte
		if(lexpType == Type.BYTE && rexpType == Type.BYTE){
			String MJ_L3 = new Label().toString();
			String MJ_L4 = new Label().toString();
			String MJ_L5 = new Label().toString();
			pout.println("# less than expression");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r18");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r24");
			pout.println("cp    r24, r18");
			pout.println("brlt " + MJ_L4 +"\n"); // MJ_L4
			pout.println("# load false");
			pout.println(MJ_L3 + ":"); // MJ_L3
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + MJ_L5 + "\n"); // MJ_L5
			pout.println("# load true");
			pout.println(MJ_L4 + ":"); // MJ_L4
			pout.println("ldi    r24, 1\n");
			pout.println("# push result of less than");
			pout.println(MJ_L5 + ":"); // MJ_L5
			pout.println("# push one byte expression onto stack");
			pout.println("push   r24");
			pout.println("");
		}
		
		
	}
	
    public void outMeggyToneStart(MeggyToneStart node){
        pout.println("### Meggy.toneStart(tone, time_ms) call");
        pout.println("# load a two byte expression off stack");
        pout.println("pop	r22");
        pout.println("pop	r23");
        pout.println("# load a two byte expression off stack");
        pout.println("pop	r24");
        pout.println("pop	r25");
        pout.println("call	_Z10Tone_Startjj");
        pout.println("");
	}

	public void outEqualExp(EqualExp node){
		// both int
		Type lexpType = this.symTbl.getExpType(node.getLExp());
		Type rexpType = this.symTbl.getExpType(node.getRExp());

		if(lexpType == Type.INT && rexpType == Type.INT){
			String true_branch = new Label().toString();
			String false_branch = new Label().toString();
			String result_branch = new Label().toString();
			pout.println("# equality check expression");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r18");
			pout.println("pop    r19");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("cp    r24, r18");
			pout.println("cpc   r25, r19");
			pout.println("breq      " + true_branch); // true
			pout.println("# result is false");
			pout.println(false_branch + ":"); // false
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + result_branch); // result
			pout.println("# result is true");
			pout.println(true_branch + ":"); // true
			pout.println("ldi     r24, 1");
			pout.println("# store result of equal expression");
			pout.println(result_branch + ":"); // result
			pout.println("# push one byte expression onto stack");
			pout.println("push   r24");
			pout.println("");
		}
	
		// first byte second int.
		if(lexpType == Type.BYTE && rexpType == Type.INT){
			String branch_6 = new Label().toString();
			String branch_7 = new Label().toString();
			String branch_4 = new Label().toString();
			String branch_3 = new Label().toString();
			String branch_5 = new Label().toString();
			pout.println("# equality check expression");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r18");
			pout.println("pop    r19");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r24");
			pout.println("# promoting a byte to an int");
			pout.println("tst     r24");
			pout.println("brlt     " + branch_6); // branch_6
			pout.println("ldi    r25, 0");
			pout.println("jmp    " + branch_7); // branch_7
			pout.println(branch_6 + ":"); // branch_6
			pout.println("ldi    r25, hi8(-1)");
			pout.println(branch_7 + ":"); // branch_7
			pout.println("cp    r24, r18");
			pout.println("cpc   r25, r19");
			pout.println("breq " + branch_4); // branch_4
			pout.println("# result is false");
			pout.println(branch_3 + ":"); // branch_3
			pout.println("ldi	   r24, 0");
			pout.println("jmp      " + branch_5); // branch_5
			pout.println("# result is true");
			pout.println(branch_4 + ":"); // branch_4
			pout.println("ldi     r24, 1");
			pout.println("# store result of equal expression");
			pout.println(branch_5 + ":"); // branch_5
			pout.println("# push one byte expression onto stack");
			pout.println("push   r24");
			pout.println("");
		}
		// both byte
		if(lexpType == Type.BYTE && rexpType == Type.BYTE){
			String true_branch = new Label().toString();
			String false_branch = new Label().toString();
			String result_branch = new Label().toString();
			pout.println("# equality check expression");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r18");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r24");
			pout.println("cp    r24, r18");
			pout.println("breq      " + true_branch); // true
			pout.println("# result is false");
			pout.println(false_branch + ":"); // false
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + result_branch); // result
			pout.println("# result is true");
			pout.println(true_branch + ":"); // true
			pout.println("ldi     r24, 1");
			pout.println("# store result of equal expression");
			pout.println(result_branch + ":"); // result
			pout.println("# push one byte expression onto stack");
			pout.println("push   r24");
			pout.println("");
		}		
		// first int second byte
		if(lexpType == Type.INT && rexpType == Type.BYTE){
			String branch_6 = new Label().toString();
			String branch_7 = new Label().toString();
			String branch_4 = new Label().toString();
			String branch_5 = new Label().toString();
			pout.println("# equality check expression");
			pout.println("# load a one byte expression off stack");
			pout.println("pop    r18");
			pout.println("# load a two byte expression off stack");
			pout.println("pop    r24");
			pout.println("pop    r25");
			pout.println("# promoting a byte to an int");
			pout.println("tst     r18");
			pout.println("brlt     " + branch_6); // branch_6
			pout.println("ldi    r19, 0");
			pout.println("jmp    " + branch_7); // branch_7
			pout.println(branch_6 + ":"); // branch_6
			pout.println("ldi    r19, hi8(-1)");
			pout.println(branch_7 + ":"); // branch_7
			pout.println("cp    r24, r18");
			pout.println("cpc   r25, r19");
			pout.println("breq " + branch_4); // branch_4
			pout.println("# result is false");
			pout.println("ldi     r24, 0");
			pout.println("jmp      " + branch_5); // branch_5
			pout.println("# result is true");
			pout.println(branch_4 + ":"); // branch_4
			pout.println("ldi     r24, 1");
			pout.println("# store result of equal expression");
			pout.println(branch_5 + ":"); // branch_5
			pout.println("# push one byte expression onto stack");
			pout.println("push   r24");
			pout.println("");
		}
	}
	
	public void outThisExp(ThisLiteral node){
/*		VarSTE varSte = (VarSTE)symTbl.lookup(node.toString());
		pout.println(" # load a one byte variable from base+offset");
		pout.println("ldd	r24, " + varSte.getBase() + " + " + varSte.getOffset());
*/		
		pout.println("# loading the implicit \"this\"");
		pout.println("# load a two byte variable from base+offset");
		pout.println("ldd    r31, Y + 2");
		pout.println("ldd    r30, Y + 1");
		pout.println("# push two byte expression onto stack");
		pout.println("push   r31");
		pout.println("push   r30\n");
		
	}
	// todo: change size
	public void outNewExp(NewExp node){
		// todo
		System.out.println("\nin AVRgenVisitor.outNewExp(" + node.getId() + ") ...");
		//System.out.println("==========================" + node);
		//System.out.println("==========================" + symTbl.getExpType(node));
		//System.out.println("==========================" + Type.getClassType(node.getId()));
		int totalSize = 0;
		ClassSTE classSte = symTbl.lookupClass(node.getId());
		System.out.println("classSte: " + classSte + " size: " + classSte.size);
		
		pout.println("# NewExp");
		pout.println("ldi    r24, lo8(" + classSte.size + ")");
		pout.println("ldi    r25, hi8(" + classSte.size + ")");
		pout.println("# allocating object of size " + classSte.size + " on heap"); // not sure about size
		pout.println("call    malloc");
		pout.println("# push object address");
		pout.println("# push two byte expression onto stack");
		pout.println("push   r25");
		pout.println("push   r24\n");
	}
	
	public void outNotExp(NotExp node){
		pout.println("# not operation");
		pout.println("# load a one byte expression off stack");
		pout.println("pop    r24");
		pout.println("ldi     r22, 1");
		pout.println("eor     r24,r22");
		pout.println("# push one byte expression onto stack");
		pout.println("push   r24");
		pout.println("");
	}
	
	public void outMeggyCheckButton(MeggyCheckButton node){
		//Meggy.Button.Up -> Button_up
		String[] buttonStringParts = ((ButtonLiteral)node.getExp()).getLexeme().split("\\."); 
		String button_val =  buttonStringParts[1]+"_"+buttonStringParts[2];
		pout.println("### MeggyCheckButton");
		pout.println("call    _Z16CheckButtonsDownv");
		pout.println("lds    r24, " + button_val);
		pout.println("# push one byte expression onto stack");
		pout.println("push   r24");
		pout.println("");
	}
	
	public void outButtonExp(ButtonLiteral node){
    	pout.println("# Button expression "+node.getLexeme());
    	pout.println("ldi    r22" + node.getIntValue() + "");
    	pout.println("# push onto stack as single byte");
    	pout.println("push   r22");
    	pout.println("");
	}	
	
	public void outColorExp(ColorLiteral node){
		pout.println("# Color expression" + node.getLexeme());
		pout.println("ldi    r22," + node.getIntValue());
		pout.println("# push one byte expression onto stack");
		pout.println("push   r22");
		pout.println("");
	}
	
	public void outToneExp(ToneLiteral node){
		pout.println("# Push " + node.getLexeme() + " onto the stack.");
		pout.println("ldi    r25, hi8(" + node.getIntValue() + ")");
		pout.println("ldi    r24, lo8(" + node.getIntValue() + ")");
		pout.println("# push two byte expression onto stack");
		pout.println("push   r25");
		pout.println("push   r24");
		pout.println("");

	}
	
	public void outIdLiteral(IdLiteral node){
		System.out.println("\nin AVRGenVisitor.outIdLiteral(" + node.toString() + ") ...");
		pout.println("# IdExp");
		
		pout.println("# load value for variable " + node.toString()); //
		pout.println("# variable is a local or param variable");
		
		//VarSTE varSte = (VarSTE)symTbl.lookup(node.toString());
		VarSTE varSte = (VarSTE)symTbl.lookupVar(node.toString());
		if(varSte.getBase() == "Z"){
				pout.println("# loading the implicit \"this\"");
				pout.println("# load a two byte variable from base+offset");
				pout.println("ldd    r31, Y + 2");
				pout.println("ldd    r30, Y + 1");
		}
		if(varSte.getType().getAVRTypeSize() == 2){
			pout.println("ldd	r24, "+varSte.getBase()+"+"+(varSte.getOffset()+1));
			pout.println("push	r24\n");			
		}
		pout.println("ldd	r24, "+varSte.getBase()+"+"+varSte.getOffset());
		pout.println("push	r24\n");

	}
	
	public void outAssignStatement(AssignStatement node){
		System.out.println("\nin AVRGenVisitor.outAssignStatement(" + node.getExp() + ") ...");
		
		pout.println("### AssignStatement");
		pout.println("# load rhs exp");
		// get the size of rhs
		VarSTE varSte = symTbl.lookupVar(node.getId());
		Type right = varSte.getType();
		int size = right.getAVRTypeSize();
		System.out.println("varSte.getType(): " + varSte.getType());
		System.out.println("varSte.getOffset(): " + varSte.getOffset());
		System.out.println("varSte.getBase(): " + varSte.getBase());
		if(size == 1){
			pout.println("# load a one byte expression off stack");
			pout.println("pop	r24");
			if(varSte.getBase() == "Z"){
				pout.println("# loading the implicit \"this\"");
				pout.println("# load a two byte variable from base+offset");
				pout.println("ldd    r31, Y + 2");
				pout.println("ldd    r30, Y + 1");
			}
			pout.println("# store rhs into var " + node.getId());
			pout.println("std	" + varSte.getBase() + " + " + varSte.getOffset() + ", r24\n");
		} else if(size == 2){
			pout.println("# load a two byte expression off stack");
			pout.println("pop	r24");
			pout.println("pop	r25");
			if(varSte.getBase() == "Z"){
				pout.println("# loading the implicit \"this\"");
				pout.println("# load a two byte variable from base+offset");
				pout.println("ldd    r31, Y + 2");
				pout.println("ldd    r30, Y + 1");
			}															
			pout.println("# store rhs into var " + node.getId());
			pout.println("std	" + varSte.getBase() + " + " + (varSte.getOffset()+1) +", r25");
			pout.println("std	" + varSte.getBase() + " + " + varSte.getOffset() + ", r24\n");
		}

		/*

    std    Y + 6, r25
    std    Y + 5, r24
		*/
		
		
	}

	
}


