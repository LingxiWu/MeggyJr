import meggy.Meggy;

class PATestInvalidWhile {
   public static void main(String[] whatever){
		while(1){
			Meggy.setPixel(1, 2, Meggy.Color.BLUE );
		}
   }
}
