import meggy.Meggy;

class PATestInvalidDelay {
   public static void main(String[] whatever){
		if(true){
			Meggy.delay((byte)1000);
		}
   }
}
