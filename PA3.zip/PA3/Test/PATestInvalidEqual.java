import meggy.Meggy;

class PATestInvalidEqual {
   public static void main(String[] whatever){
		if((byte)1 == 1){
			Meggy.delay(1000);
		}

		if(1 == Meggy.Color.DARK){
			Meggy.delay(3000);
		}
   }
}
