import meggy.Meggy;

class PATestInvalidMinus {
   public static void main(String[] whatever){
		if(Meggy.Color.RED-1==2){
			Meggy.delay(1000);
		}
   }
}
