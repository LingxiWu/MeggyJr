import meggy.Meggy;

class PATestInvalidAnd {
   public static void main(String[] whatever){
		if(true && 1){
			Meggy.delay(1000);
		}
   }
}
