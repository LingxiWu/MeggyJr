import meggy.Meggy;

class PATestInvalidIf {
   public static void main(String[] whatever){
		if(1){
			Meggy.setPixel((byte)1, (byte)2, Meggy.Color.BLUE );
		}
   }
}
