name: Lingxi Wu (lw2ef)
date: 10/26/2018

********** ajor Directory Structure **********
*** NOTICE: directories or files that I created/modified/edited are marked with * at the front
PA3
  |___java_cup
  |___meggy
  |___mjsimPictures
 _|___*src
| |___*Test---				     
|            |____meggy                        
|	     |____*WorkingTestCases---------------
|	     |____*WorkingErrorTestCases--       |___PAbuttondot.java.arg_opts
|					 |       |___Byte.java
|________				 |       |___CondExpr.java
	 |__*ast--------------		 |       |___If.java
         |__*ast_visitors--  |__nodes    |       |___IfStmt.java
         |__exceptions    |  |__visitors |       |___PA2bluedot.java
	 |__label	  |		 |       |___PA2FlowerSimple.java
	 |__*mjparser---  |		 |       |___PA3buttondot.java
	 |__symtable   |  |		 |       |___PA3Cylon.java
            	       |  |              |       |___PA3Expressions.java
	   *mj.cup_____|  |		 |       |___PATestEmpty.java
            mj.lex_____|  |		 |___PATestInvalidWhile.java  
  SymbolValue.java_____|  |		 |___ErrorSetPixel.java
            MJ.jar_____|  |		 |___PA2error.java
	         	  |		 |___PATestIntSetPixel.java
			  |		 |___PATestInvalidIf.java
			  |		 |___PATestInvalidDelay.java
			  |		 |___PATestInvalidAnd.java
			  |		 |___PATestInvalidEqual.java
			  |		 |___PATestInvalidTimes.java
			  |		 |___PATestInvalidMInus.java
			  |
	         	  |___*A VRgenVisitor.java
                          |___*CheckTypes.java
                          |___DotVisitor.java
		          |___DotVisitorWithMap.java



********** Build Process **********
1. To generate MJ.jar:
	in /PA3, "make clean; make"

2. To compile a MeggyJava file:
	in /PA3, "java -jar MJ.jar dir/to/<meggyjavafile>.java

3. To simulate a MeggyJava file in MJSIM.jar:
	in /PA3, "java -jar MJSIM.jar --batch --file dir/to/<meggyjavafile>.java.s

4. To run regression test on all testing cases:
	in /PA3/Test, "./regress.sh" which will go through all files in both /WorkingTestCases and 				/WorkingErrorTestCases.
	
5. To fun test on a single meggyjava case against reference mj compiler:
	in /PA3/Test, "./regress.sh dir/to/<meggyjavafile>.java"

********** About Test Cases **********
Testing cases covers the following areas:
	(1). empty statement program
	(2). setting pixels with constant integer expressions
	(3). setting pixels with color literals
	(4). settingpixels with byte casting
	(5). sequaence  of statements with setPixel calls
	(6). button presses (Meggy.chekButton)
	(7). Use of the delay function (Meggy.delay)
	(8). functtion for reading the screen pixel values (Meggy.getPixel)
	(9). while statement
	(10). if statement
	(11). byte casts
	(12). operators plus, minus, and times
	(13). boolean expressions




