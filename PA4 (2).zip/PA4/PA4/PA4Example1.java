import meggy.Meggy;

class PA4Example1 {

    public static void main(String[] whatever){
    }	
}

class something {
	
	public void inBounds(byte a, int b, boolean c, Meggy.Button d, Meggy.Tone e, Meggy.Color f) {
    }
}
class something1{
	public void inBounds1(byte a, int b, boolean c, Meggy.Button d, Meggy.Tone e, Meggy.Color f){ }
}

