/**
 * PA4Test3.java
 * Associate yellow with c3 tone.
 */

import meggy.Meggy;

class PA4Test3 {

    public static void main(String[] args){  
    	Meggy.setPixel((byte)0, (byte)0, Meggy.Color.YELLOW);
		Meggy.delay(1000);
		new Utility().playColorTone((byte)0, (byte)0);
    }
}

class Utility {
	public void playColorTone(byte x, byte y){
		if(Meggy.getPixel((byte)x, (byte)y) == Meggy.Color.YELLOW){
			// If it's yellow, play tone c3.
			Meggy.toneStart(Meggy.Tone.C3, 50);
			
			// keep playing for a while.
			while(true){
				Meggy.toneStart(Meggy.Tone.C3, 50);
				Meggy.delay(500);
			}  
		}
	}
}
