package ast_visitors;

import ast.node.*;
import ast.visitor.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;
import java.io.PrintWriter;
import symtable.SymTable;
import symtable.Type;
import symtable.STE;
import symtable.Signature;
import symtable.*;
import exceptions.SemanticException;

public class BuildSymTable extends DepthFirstVisitor{
	
	private SymTable symTable = new SymTable();
	
	public void inTopClassDecl(TopClassDecl node){
		// look up class name
		System.out.println("inTopClassDecl inBuildSymTable");
		if(symTable.lookupInnermost(node.getName()) != null){
			throw new SemanticException("Class " + node.getName() + " already defined!");
		}
		// create class_ste
		// ClassSTE(String mName, boolean mMain, String mSuperClass, Scope scope)
		ClassSTE ste = new ClassSTE(node.getName(), false, null);
		
		
	}

	public void inMethodDecl(MethodDecl node){
		// Look up method name in current symbol table to see if there are any duplicates.  
		// only look into the innermost scope
		System.out.println("in inMethodDecl");
		if(symTable.lookupInnermost(node.getName()) != null){
			throw new SemanticException("Method " + node.getName() + " already defined!");
		}
		// create a function signature
		System.out.println(node.getFormals());
		// create a MethodSTE
		
		// insert the MethodSTE into the symbol table with SymTable.insert
		
	}
	
	public Type convertType(IType iType){
		return null;
	}
	
	public SymTable getSymTable() {
        return this.symTable;
	}
	

}
