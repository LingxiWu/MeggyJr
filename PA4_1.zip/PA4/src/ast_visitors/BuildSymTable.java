package ast_visitors;

import ast.node.*;
import ast.visitor.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;
import java.io.PrintWriter;
import symtable.SymTable;
import symtable.Type;
import symtable.STE;
import symtable.Signature;
import symtable.*;
import exceptions.SemanticException;

public class BuildSymTable extends DepthFirstVisitor{
	
	private final SymTable symTable = new SymTable();
	private ClassSTE currentClass; // memory the current class STE when we encounter a class
	public int offset;
	
	public void inTopClassDecl(TopClassDecl node){
		// look up class name
		System.out.println("\nin BuildSymTable.inTopClassDecl(" + node.getName() + ") ... ");
		if(symTable.lookupInnermost(node.getName()) != null){
			throw new SemanticException("Class " + node.getName() + " already defined!");
		}
		
		// create class_ste
		// ClassSTE(String mName, boolean mMain, String mSuperClass, Scope enclosing)
		Scope classScope = new Scope("Class",symTable.peekScopeStack());
		ClassSTE classSte = new ClassSTE(node.getName(), false, null, classScope);
		
		// insert into current scope stack
		symTable.insert(classSte);
		System.out.println("inserted " + classSte.toString());
		// push it to the top on the scope stack
		symTable.pushScope(node.getName());	
		System.out.println("pushed " + classSte.toString());
		System.out.println("after push, scope is like this: "+symTable.mScopeStack);
		// put current class into classTypes
		Type.createClassType(node.getName());
		System.out.println("");
		
		// memorize current class ste
		currentClass = classSte;
	}

	public void outTopClassDecl(TopClassDecl node){
		System.out.println("\nin BuildSymTable.outTopClassDecl(" + node.getName() + ") ... ");
		System.out.println("pop top of the scope stack");
		System.out.println("after pop, scope is like this: "+symTable.mScopeStack +"\n");
		symTable.popScope();
	}

	public void inMethodDecl(MethodDecl node){
		// Look up method name in current symbol table to see if there are any duplicates.  
		// only look into the innermost scope
		System.out.println("in BuildSymTable.inMethodDecl(" + node.getName() + ") ... ");
		
		if(symTable.lookupInnermost(node.getName()) != null){
			throw new SemanticException("Method " + node.getName() + " already defined!");
		}
		// create a function signature
		LinkedList<Formal> formal_list = node.getFormals();
		LinkedList<Type> formalType_list = new LinkedList<Type>();
		Iterator itr = formal_list.iterator();
		while(itr.hasNext()){
			formalType_list.add(convertType(((Formal)itr.next()).getType()));
		}
		Signature signature = new Signature(convertType(node.getType()), formalType_list);
		// create a MethodSTE
		Scope methodScope = new Scope("Method",symTable.peekScopeStack());
		// MethodSTE(String mName, Signature mSignature, Scope scope)
		MethodSTE methodSTE = new MethodSTE(node.getName(), signature, methodScope);
		
		// insert the MethodSTE into the symbol table with SymTable.insert		
		symTable.insert(methodSTE);
		System.out.println("inserted " + methodSTE.toString());
		
		// push it to the top on the scope stack
		symTable.pushScope(node.getName());
		System.out.println("pushed " + methodSTE.toString());
		System.out.println("after push, scope is like this: "+symTable.mScopeStack);
		// set current offset in visitor to 1 
		offset = 1;
		System.out.println("in BuildSymTable.inMethodDecl() ...");
		System.out.println("add \"this\" to var scope");
		// insert "this" into scope. "this" is a class type
		VarSTE varSte = new VarSTE("this", Type.retrieveClassType(currentClass.getName()), offset);
		
		// update offset
		offset += varSte.getType().getAVRTypeSize();
		// insert varste into symbol table
		symTable.insert(varSte); 

	}
	
	public void outMethodDecl(MethodDecl node){
		System.out.println("\nin BuildSymTable.outMethodDecl(" + node.getName() + ") ... ");
		System.out.println("pop top of the scope stack");
		symTable.popScope();
		System.out.println("after pop, scope is like this: "+symTable.mScopeStack +"\n");
	}
	
	public void outFormal(Formal node){
		// check if var name has already been inserted in SymTable using st.lookup(name).  Error if 		   there is a duplicate.
		STE ste = symTable.lookupInnermost(node.getName());
		if(ste != null){
			throw new SemanticException("Redefined symbol",node.getLine(), node.getPos());
		} else {
			// create VarSTE with current method offset and type of formal
			VarSTE varSte = new VarSTE(node.getName(), convertType(node.getType()), offset);
			// increment visitor - maintained offset based on the type of the formal variable
			offset += varSte.getType().getAVRTypeSize(); 
        	// call st.insert
        	symTable.insert(varSte);
		}		 
	}
	
	public static Type convertType(IType iType){
  		if(iType instanceof BoolType){
  			return Type.BOOL;
  		}
  		if(iType instanceof IntType){
  			return Type.INT;
  		}
  		if(iType instanceof ByteType){
  			return Type.BYTE;
  		}
  		if(iType instanceof ColorType){
  			return Type.COLOR;
  		}
  		if(iType instanceof ButtonType){
  			return Type.BUTTON;
  		}
  		if(iType instanceof VoidType){
  			return Type.VOID;
  		}
  		if(iType instanceof ToneType){
  			return Type.TONE;
  		} else {
  			return null;
  		}
	}
	
	public SymTable getSymTable() {
        return this.symTable;
	}
	


}
