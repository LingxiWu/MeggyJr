package ast_visitors;

import ast.node.*;
import ast.visitor.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;
import java.io.PrintWriter;
import symtable.SymTable;
import symtable.Type;
import symtable.STE;
import symtable.Signature;
import symtable.*;
import exceptions.SemanticException;

public class BuildSymTable extends DepthFirstVisitor{
	
	private SymTable symTable = new SymTable();
	
	public void inTopClassDecl(TopClassDecl node){
		
		// look up class name
		System.out.println("in BuildSymTable.inTopClassDecl() ... ");
		if(symTable.lookupInnermost(node.getName()) != null){
			throw new SemanticException("Class " + node.getName() + " already defined!");
		}
		
		// create class_ste
		// ClassSTE(String mName, boolean mMain, String mSuperClass, Scope enclosing)
		Scope classScope = new Scope(symTable.peekScopeStack());
		ClassSTE classSte = new ClassSTE(node.getName(), false, null, classScope);
		
		// insert into current scope stack
		symTable.insert(classSte);
		System.out.println("insert " + classSte.toString());
		// push it to the top on the scope stack
		symTable.pushScope(node.getName());	
	}

	public void outTopClassDecl(TopClassDecl node){
		System.out.println("in BuildSymTable.outTopClassDecl() ... ");
		System.out.println("pop top of the scope stack");
		symTable.popScope();
	}

	public void inMethodDecl(MethodDecl node){
		// Look up method name in current symbol table to see if there are any duplicates.  
		// only look into the innermost scope
		System.out.println("in BuildSymTable.inMethodDecl() ... ");
		if(symTable.lookupInnermost(node.getName()) != null){
			throw new SemanticException("Method " + node.getName() + " already defined!");
		}
		// create a function signature
		LinkedList<Formal> formal_list = node.getFormals();
		LinkedList<Type> formalType_list = new LinkedList<Type>();
		Iterator itr = formal_list.iterator();
		while(itr.hasNext()){
			formalType_list.add(convertType(((Formal)itr.next()).getType()));
		}
		Signature signature = new Signature(convertType(node.getType()), formalType_list);
		// create a MethodSTE
		Scope methodScope = new Scope(symTable.peekScopeStack());
		// MethodSTE(String mName, Signature mSignature, Scope scope)
		MethodSTE methodSTE = new MethodSTE(node.getName(), signature, methodScope);
		
		// insert the MethodSTE into the symbol table with SymTable.insert
		symTable.insert(methodSTE);
		
		// push it to the top on the scope stack
		symTable.pushScope(node.getName());
	}
	
	public void outMethodDecl(MethodDecl node){
		System.out.println("in BuildSymTable.outMethodDecl() ... ");
		System.out.println("pop top of the scope stack");
		symTable.popScope();
	}
	
	public Type convertType(IType iType){
  		if(iType instanceof BoolType){
  			return Type.BOOL;
  		}
  		if(iType instanceof IntType){
  			return Type.INT;
  		}
  		if(iType instanceof ByteType){
  			return Type.BYTE;
  		}
  		if(iType instanceof ColorType){
  			return Type.COLOR;
  		}
  		if(iType instanceof ButtonType){
  			return Type.BUTTON;
  		}
  		if(iType instanceof VoidType){
  			return Type.VOID;
  		}
  		if(iType instanceof ToneType){
  			return Type.TONE;
  		} else {
  			return null;
  		}
	}
	
	public SymTable getSymTable() {
        return this.symTable;
	}
	


}
