package symtable;
import java.util.*;

import exceptions.SemanticException;
public class Scope {

	private final HashMap<String,STE> mDict = new HashMap<String,STE>();
	public Scope mEnclosing; // parent scope
	
	public Scope(Scope mEnclosing) {
		this.mEnclosing = mEnclosing;
	}
	
/*	// create an entry for this string-ste pair and put it in hashmap.
	public void insert(STE ste){
		mDict.put(ste.getName(), ste);
	}
*/
	
	public STE lookup(String steName){
		if(mDict.containsKey(steName)){
			return mDict.get(steName);
		} else {
			return null;
		}
	}
	
	public void insert(STE ste){
		// check if if it's var type
		if(ste instanceof VarSTE){
			// if the var is defined in current var
			if(mDict.containsKey(ste.getName())){
				throw new SemanticException("Variable " + ste.getName() + "has already been defined");
			}
		}
		mDict.put(ste.getName(), ste);
	}
	
	public STE lookupInnermost(String sym){	
		return null;
	}
	
	

}
