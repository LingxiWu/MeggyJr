package symtable;

public class ClassSTE extends STE{

	private boolean mMain;
	private String mSuperClass;
	private Scope mScope;
	
	public ClassSTE(String mName, boolean mMain, String mSuperClass){
		super(mName);
		this.mMain = mMain;
		this.mSuperClass = mSuperClass;
		this.mScope = null;
	}		

	public void setScope(Scope scope){
		mScope = scope;
	}

	public Scope getScope(){
		return mScope;
	}

}
