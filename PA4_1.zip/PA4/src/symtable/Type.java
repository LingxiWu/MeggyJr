package symtable;

import exceptions.*;

import java.util.*;


public class Type
{
  public static final Type BOOL = new Type();
  public static final Type INT = new Type();
  public static final Type BYTE = new Type();
  public static final Type COLOR = new Type();
  public static final Type BUTTON = new Type();
  public static final Type VOID = new Type();
  public static final Type TONE = new Type();
	// for maintaining a list of mappings of class types.
	private static HashMap<String, Type> classTypes = new HashMap(); 
	private static String className;
		
  private Type()
  {
	className = null;
  }
  
  // for making a new class type
  private Type(String className){
  	this.className = className;
  }
  
  public static void createClassType(String id){
    System.out.println("in Type.createClassType(" + id +") ...");
  	// create a new type based on class name.
  	Type classType = new Type(id);
  	// add this new class type into dictionary.
  	classTypes.put(id, classType);
  }
  
  public static Type retrieveClassType(String id){
  System.out.println("in Type.retrieveClassType(" + id +") ...");
  	Type type = classTypes.get(id);
  	if(type != null){
  		return type;
  	} else {
  		return null;
  	}
  }
  
  


    
/*
*/

  public String toString()
  {
    if(this == INT)
    {
      return "INT";
    }

    if(this == BOOL)
    {
      return "BOOL";
    }

    if(this == BYTE)
    {
      return "BYTE";
    }

    if(this == COLOR)
    {
      return "COLOR";
    }

    if(this == BUTTON)
    {
      return "BUTTON";
    }

    if(this == TONE)
    {
      return "TONE";
    }

    
/*
*/
    return className;
  }
  
  public int getAVRTypeSize() {
      if(this == INT) { return 2; }
      if(this == BOOL) { return 1; }
      if(this == BYTE) { return 1; }
      if(this == COLOR) { return 1; }
      if(this == BUTTON) { return 1; }
      if(this == VOID) { return 0; }
      if(this == TONE) {return 2;}

      return 2; // class references are 2 bytes
  }

    
/*  
*/

}
