package symtable;

public class MethodSTE extends STE{

	private Signature mSignature;
	private Scope mScope;
	
	public MethodSTE(String mName, Signature mSignature, Scope enclosing){
		super(mName);
		this.mSignature = mSignature;
		this.mScope = enclosing;
	}		
	
	public Scope getScope(){
		return mScope;
	}
	
	public String toString(){
		String s = "";
		s += "mName: " + getName();

		return s;
	}

	public Signature getSignature(){
		return mSignature;
	}

}
