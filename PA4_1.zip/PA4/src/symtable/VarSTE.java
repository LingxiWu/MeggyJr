package symtable;

public class VarSTE extends STE{

	private Type mType;
	private int mOffset;
	private String mBase; // ?
	
	public VarSTE(String mName, Type mType, int mOffset){
		super(mName);
		this.mType = mType;
		this.mOffset = mOffset;
		this.mBase = "Y"; // Y for local variable I guess ...
	}		

}
