package symtable;
public class STE{
	
	private String mName;
	
	public STE(String mName){
		this.mName = mName;
	}
	public void setName(String mName){
		this.mName= mName;
	}
	public String getName(){
		return this.mName;
	}
}
