
import meggy.Meggy;

class PATest {

    public static void main(String[] whatever){
			new Class_1().func1(1,2,Meggy.Color.YELLOW);
			
			
    }
    

}

class Class_1{
	public int func1(int a, int b, Meggy.Color c){
    	return 1;
  	}
  	public byte func2(byte a, int b, byte c){
    	return (byte)1;
  	}
}


