
import meggy.Meggy;

class PATest {

    public static void main(String[] whatever){

    }
    

}

class Class_1{
	public void func(int a){
    
  }
}

class Class_2{
	  public int func(int a){
    
    }
}


class Class_3{
	public void func(int a){
    
    }
}



