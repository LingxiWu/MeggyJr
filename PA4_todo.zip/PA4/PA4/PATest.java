
import meggy.Meggy;

class PA4bluedot {

    public static void main(String[] whatever){
        {
            new Simple().bluedot((byte)3, (byte)7);    
            Meggy.setPixel((byte)1, (byte)2, Meggy.Color.BLUE );
    
        }
    }
}

class Simple {
    
    public void bluedot(byte x, byte y) {
        Meggy.setPixel( x, y, Meggy.Color.BLUE );
    }

}

