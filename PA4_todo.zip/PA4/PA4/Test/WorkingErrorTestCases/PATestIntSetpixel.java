import meggy.Meggy;

class PATestIntSetpixel {
   public static void main(String[] whatever){
		while(true){
			Meggy.setPixel(1, 2, Meggy.Color.BLUE );
		}
   }
}
