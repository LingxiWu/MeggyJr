package symtable;

public class ClassSTE extends STE{

	private boolean mMain;
	private String mSuperClass;
	private Scope mScope;
	
	public class ClassSTE(String mName, boolean mMain, String mSuperClass, Scope scope){
		super(mName);
		this.mMain = mMain;
		this.mSuperClass = mSuperClass
		this.mScope = mScope;
	}		

}
