
import meggy.Meggy;

class PATest {

    public static void main(String[] whatever){

    }
    

}

class SimpleClass{
	public void func(int a){
    
    }
}



